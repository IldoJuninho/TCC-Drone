#include "Joystick.h"
#define Atime 1000
#include <chrono>
#include <ctime>

int aux = -1;
int wait = 1;

Joystick controle = Joystick();

void setup(){
  Serial.begin(115200);
  controle.init();
  // Configura o timeout da Serial (Milliseconds)
  Serial.setTimeout(1); 
}

std::chrono::time_point<std::chrono::system_clock> start = std::chrono::system_clock::now();
std::chrono::time_point<std::chrono::system_clock> end = std::chrono::system_clock::now();
std::chrono::duration<double> elapsed_seconds = end - start;


void loop() {
	if (Serial.available() > 0){
		String msg = Serial.readStringUntil(';');
		Serial.println(msg);
		//Serial.println("REceba");

		aux = controle.processMSG(msg);

		

		// Se não for um rotina atua nos DACs 
		if(aux){
			// controle.dacActutor();
			start = std::chrono::system_clock::now();
			wait =1;
		}
		
		// if (controle.rest){
		// 	controle.returnRest();
		// 	controle.rest = false;
		// }
		
	}

	end= std::chrono::system_clock::now();
	elapsed_seconds=end-start;
	double tt=0.3;
	if(controle.pouso>=1){tt=0.3;}
	if(wait==1 and elapsed_seconds.count()<=tt){
			controle.dacActutor();
	}else{
		wait=0;
		if (controle.pouso==1){
			controle.returnRest(95);
		}else if (controle.pouso==2)
		{
			controle.returnRest(60);
		} else{
			controle.returnRest(118);
		}
		
	
	}

	//delay(1);
	//Serial.println("lendo");
}